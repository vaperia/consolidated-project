﻿import { useContext } from "react";
import { Navigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";

export default function ProtectedRoute({ children }) {
    const { user, authLoading } = useContext(AuthContext);

    if (authLoading) return <div style={{ padding: 20 }}>Loading...</div>;
    if (!user) return <Navigate to="/" replace />;

    return children;
}

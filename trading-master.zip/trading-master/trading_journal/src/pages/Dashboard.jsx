﻿import { useContext, useEffect, useState } from "react";
import { AuthContext } from "../context/AuthContext";
import { db } from "../utils/firebase";
import {
    collection,
    query,
    where,
    onSnapshot,
    getDocs,
} from "firebase/firestore";
import { Link, useNavigate } from "react-router-dom";
import EditTrade from "./EditTrade";

/* ================= DASHBOARD ================= */

export default function Dashboard() {
    const { user } = useContext(AuthContext);
    const navigate = useNavigate();

    const [trades, setTrades] = useState([]);
    const [analyses, setAnalyses] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    /* ================= LOAD TRADES ================= */
    useEffect(() => {
        if (!user) return;

        const q = query(
            collection(db, "trades"),
            where("userId", "==", user.uid)
        );

        const unsub = onSnapshot(
            q,
            (snapshot) => {
                setTrades(snapshot.docs.map(d => ({ id: d.id, ...d.data() })));
                setLoading(false);
            },
            (err) => {
                console.error(err);
                setError("Failed to load trades.");
                setLoading(false);
            }
        );

        return () => unsub();
    }, [user]);

    /* ================= LOAD DAILY ANALYSIS ================= */
    useEffect(() => {
        if (!user) return;

        const loadAnalyses = async () => {
            const q = query(
                collection(db, "daily_analysis"),
                where("userId", "==", user.uid)
            );
            const snap = await getDocs(q);
            setAnalyses(snap.docs.map(d => ({ id: d.id, ...d.data() })));
        };

        loadAnalyses();
    }, [user]);

    if (!user) return <p>Please log in.</p>;
    if (loading) return <p>Loading dashboard...</p>;
    if (error) return <p>{error}</p>;

    /* ================= SPLIT TRADES ================= */
    const openTrades = trades.filter(t => t.status === "OPEN");
    const closedTrades = trades.filter(t => t.status === "CLOSED");

    /* ================= HELPERS ================= */
    const renderCharts = (charts) => {
        if (!charts) return null;
        return (
            <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
                {charts.H1 && <img src={charts.H1} width={120} />}
                {charts.M15 && <img src={charts.M15} width={120} />}
                {charts.M5 && <img src={charts.M5} width={120} />}
            </div>
        );
    };

    return (
        <div style={{ padding: 20 }}>
            <h2>Dashboard</h2>

            {/* ================= ACTION BAR ================= */}
            <div style={{ display: "flex", gap: 10, marginBottom: 20 }}>
                <Link to="/add-trade">
                    <button style={btnPrimary}>+ Add Trade</button>
                </Link>

                <Link to="/analysis">
                    <button>+ Daily Analysis</button>
                </Link>

                <button style={btnSecondary} onClick={() => navigate("/calendar")}>
                    🗓 Calendar
                </button>
            </div>

            {/* ================= DAILY MARKET ANALYSIS ================= */}
            <h3>Daily Market Analysis</h3>

            {analyses.length === 0 && <p>No daily analysis yet.</p>}

            {analyses.map(a => (
                <div key={a.id} style={analysisCard}>
                    <h4>{a.date} — {a.pair}</h4>

                    <b>Bias</b>
                    <p>{a.pre?.bias}</p>

                    <b>Plan</b>
                    <p>{a.pre?.executionPlan}</p>

                    {renderCharts(a.pre?.images)}

                    {a.post && (
                        <>
                            <hr />
                            <b>Post-Session Reflection</b>
                            <p>{a.post.reflection}</p>
                            {renderCharts(a.post.images)}
                        </>
                    )}

                    <button onClick={() => navigate(`/analysis/${a.id}`)}>
                        Edit Post Analysis
                    </button>
                </div>
            ))}

            {/* ================= OPEN TRADES ================= */}
            <h3 style={{ marginTop: 30 }}>Open Trades</h3>
            {openTrades.length === 0 && <p>No open trades.</p>}

            {openTrades.map(trade => (
                <div key={trade.id} style={tradeCard}>
                    <strong>{trade.ticker}</strong> ({trade.direction})

                    <div>Entry: {trade.entry_price}</div>
                    <div>
                        Size: {trade.quantity} | Remaining:{" "}
                        <b>{trade.remaining_qty}</b>
                    </div>

                    <div>
                        Realized PnL:{" "}
                        <span style={{
                            color: trade.pnl >= 0 ? "green" : "red",
                            fontWeight: "bold"
                        }}>
                            {trade.pnl?.toFixed(2)}
                        </span>
                    </div>

                    {renderCharts(trade.charts)}

                    {trade.partial_closes?.length > 0 && (
                        <div style={{ marginTop: 8 }}>
                            <b>Partial Closes</b>
                            {trade.partial_closes.map((pc, i) => (
                                <div key={i} style={{ fontSize: 13 }}>
                                    • {pc.qty} @ {pc.exit_price} → PnL {pc.pnl}
                                </div>
                            ))}
                        </div>
                    )}

                    <EditTrade trade={trade} />
                </div>
            ))}

            {/* ================= CLOSED TRADES ================= */}
            <h3 style={{ marginTop: 30 }}>Closed Trades</h3>
            {closedTrades.length === 0 && <p>No closed trades.</p>}

            {closedTrades.map(trade => (
                <div key={trade.id} style={tradeCard}>
                    <strong>{trade.ticker}</strong> ({trade.direction})

                    <div>
                        Entry: {trade.entry_price} → Exit: {trade.exit_price}
                    </div>

                    <div>Size: {trade.quantity}</div>

                    <div>
                        Total PnL:{" "}
                        <span style={{
                            color: trade.pnl >= 0 ? "green" : "red",
                            fontWeight: "bold"
                        }}>
                            {trade.pnl?.toFixed(2)}
                        </span>
                    </div>

                    {renderCharts(trade.charts)}

                    {trade.partial_closes?.length > 0 && (
                        <div style={{ marginTop: 8 }}>
                            <b>Execution Breakdown</b>
                            {trade.partial_closes.map((pc, i) => (
                                <div key={i} style={{ fontSize: 13 }}>
                                    • {pc.qty} @ {pc.exit_price} → PnL {pc.pnl}
                                </div>
                            ))}
                        </div>
                    )}

                    <button
                        style={{ marginTop: 10 }}
                        onClick={() =>
                            navigate(`/trade-journal?tradeId=${trade.id}`)
                        }
                    >
                        📝 Trade Journal
                    </button>
                </div>
            ))}
        </div>
    );
}

/* ================= STYLES ================= */

const btnPrimary = {
    padding: "8px 14px",
    background: "#2563eb",
    color: "white",
    border: "none",
    borderRadius: 6,
    cursor: "pointer",
};

const btnSecondary = {
    padding: "8px 14px",
    background: "#e5e7eb",
    border: "1px solid #ccc",
    borderRadius: 6,
    cursor: "pointer",
};

const tradeCard = {
    border: "1px solid #333",
    padding: 12,
    marginBottom: 12,
};

const analysisCard = {
    border: "1px solid #444",
    padding: 12,
    marginBottom: 12,
};

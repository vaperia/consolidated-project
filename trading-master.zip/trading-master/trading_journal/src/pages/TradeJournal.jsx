﻿import { useContext, useEffect, useState } from "react";
import { AuthContext } from "../context/AuthContext";
import { db, storage } from "../utils/firebase";
import {
    addDoc,
    collection,
    doc,
    getDoc,
    query,
    where,
    getDocs,
    updateDoc,
    serverTimestamp,
} from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { useNavigate, useSearchParams } from "react-router-dom";

export default function TradeJournal() {
    const { user } = useContext(AuthContext);
    const [params] = useSearchParams();
    const navigate = useNavigate();

    /* ================= GUARDS ================= */
    if (!user) return <p>Loading user...</p>;

    const tradeId = params.get("tradeId");
    if (!tradeId) return <p>No trade selected.</p>;

    const [trade, setTrade] = useState(null);
    const [journalId, setJournalId] = useState(null);

    const [analyses, setAnalyses] = useState([]);
    const [dailyAnalysisId, setDailyAnalysisId] = useState("");

    const [form, setForm] = useState({
        entryReason: "",
        managementNotes: "",
        exitReason: "",
        psychology: "",
        lessons: "",
    });

    const [charts, setCharts] = useState({
        entry: {},
        exit: {},
    });

    /* ================= LOAD TRADE ================= */
    useEffect(() => {
        const loadTrade = async () => {
            const snap = await getDoc(doc(db, "trades", tradeId));
            if (snap.exists()) {
                setTrade(snap.data());
            }
        };
        loadTrade();
    }, [tradeId]);

    /* ================= LOAD DAILY ANALYSES ================= */
    useEffect(() => {
        const loadAnalyses = async () => {
            const q = query(
                collection(db, "daily_analysis"),
                where("userId", "==", user.uid)
            );
            const snap = await getDocs(q);
            setAnalyses(snap.docs.map(d => ({ id: d.id, ...d.data() })));
        };
        loadAnalyses();
    }, [user]);

    /* ================= LOAD EXISTING JOURNAL ================= */
    useEffect(() => {
        const loadJournal = async () => {
            const q = query(
                collection(db, "trade_journals"),
                where("tradeId", "==", tradeId),
                where("userId", "==", user.uid)
            );
            const snap = await getDocs(q);

            if (!snap.empty) {
                const d = snap.docs[0];
                setJournalId(d.id);

                const data = d.data();
                setForm({
                    entryReason: data.entryReason || "",
                    managementNotes: data.managementNotes || "",
                    exitReason: data.exitReason || "",
                    psychology: data.psychology || "",
                    lessons: data.lessons || "",
                });
                setCharts(data.charts || { entry: {}, exit: {} });
                setDailyAnalysisId(data.dailyAnalysisId || "");
            }
        };
        loadJournal();
    }, [tradeId, user]);

    /* ================= IMAGE UPLOAD ================= */
    const uploadImage = async (file, section, tf) => {
        if (!file) return null;
        const path = `users/${user.uid}/trade_journal/${tradeId}/${section}_${tf}.png`;
        const imgRef = ref(storage, path);
        await uploadBytes(imgRef, file);
        return await getDownloadURL(imgRef);
    };

    /* ================= SAVE ================= */
    const handleSave = async () => {
        if (!trade) return;

        const payload = {
            userId: user.uid,
            tradeId,
            dailyAnalysisId: dailyAnalysisId || null,
            ...form,
            charts,
            updatedAt: serverTimestamp(),
        };

        if (journalId) {
            await updateDoc(doc(db, "trade_journals", journalId), payload);
        } else {
            await addDoc(collection(db, "trade_journals"), {
                ...payload,
                createdAt: serverTimestamp(),
            });
        }

        navigate("/dashboard");
    };

    if (!trade) return <p>Loading trade...</p>;

    return (
        <div style={{ padding: 20 }}>
            <h2>Trade Journal</h2>
            <b>{trade.ticker} ({trade.direction})</b>

            {/* ===== Link Daily Analysis ===== */}
            <div style={{ marginTop: 12 }}>
                <label>Linked Daily Analysis (optional)</label>
                <select
                    value={dailyAnalysisId}
                    onChange={(e) => setDailyAnalysisId(e.target.value)}
                >
                    <option value="">— None —</option>
                    {analyses.map(a => (
                        <option key={a.id} value={a.id}>
                            {a.date} — {a.pair}
                        </option>
                    ))}
                </select>
            </div>

            {/* ===== Text Areas ===== */}
            <textarea
                placeholder="Why did I take this trade?"
                value={form.entryReason}
                onChange={e => setForm({ ...form, entryReason: e.target.value })}
            />

            <textarea
                placeholder="How did I manage the trade?"
                value={form.managementNotes}
                onChange={e => setForm({ ...form, managementNotes: e.target.value })}
            />

            <textarea
                placeholder="Why did I exit?"
                value={form.exitReason}
                onChange={e => setForm({ ...form, exitReason: e.target.value })}
            />

            <textarea
                placeholder="Psychology & emotions"
                value={form.psychology}
                onChange={e => setForm({ ...form, psychology: e.target.value })}
            />

            <textarea
                placeholder="Lessons learned"
                value={form.lessons}
                onChange={e => setForm({ ...form, lessons: e.target.value })}
            />

            {/* ===== Entry Charts ===== */}
            <h4>Entry Charts</h4>
            {["H1", "M15", "M5"].map(tf => (
                <input
                    key={tf}
                    type="file"
                    onChange={async (e) => {
                        const url = await uploadImage(e.target.files[0], "entry", tf);
                        setCharts(c => ({
                            ...c,
                            entry: { ...c.entry, [tf]: url },
                        }));
                    }}
                />
            ))}

            {/* ===== Exit Charts ===== */}
            <h4>Exit Charts</h4>
            {["H1", "M15", "M5"].map(tf => (
                <input
                    key={tf}
                    type="file"
                    onChange={async (e) => {
                        const url = await uploadImage(e.target.files[0], "exit", tf);
                        setCharts(c => ({
                            ...c,
                            exit: { ...c.exit, [tf]: url },
                        }));
                    }}
                />
            ))}

            <button onClick={handleSave}>
                Save Trade Journal
            </button>
        </div>
    );
}

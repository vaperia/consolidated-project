﻿import { useState } from "react";
import { db } from "../utils/firebase";
import {
    doc,
    updateDoc,
    arrayUnion,
    Timestamp,
    increment,
} from "firebase/firestore";

export default function EditTrade({ trade }) {
    const [closeQty, setCloseQty] = useState("");
    const [exitPrice, setExitPrice] = useState("");
    const [closePnL, setClosePnL] = useState("");

    const handlePartialClose = async () => {
        const qty = Number(closeQty);
        const pnl = Number(closePnL);
        const price = Number(exitPrice);

        if (!qty || !price || isNaN(pnl)) {
            alert("Enter valid quantity, exit price, and PnL");
            return;
        }

        const remaining = trade.remaining_qty ?? trade.quantity;

        if (qty > remaining) {
            alert("Cannot close more than remaining quantity");
            return;
        }

        const newRemaining = remaining - qty;
        const isFinalClose = newRemaining === 0;

        try {
            await updateDoc(doc(db, "trades", trade.id), {
                remaining_qty: newRemaining,

                // accumulate total pnl
                pnl: increment(pnl),

                partial_closes: arrayUnion({
                    qty,
                    exit_price: price,
                    pnl,
                    closedAt: Timestamp.now(),
                }),

                ...(isFinalClose && {
                    status: "CLOSED",
                    exit_price: price,
                    date_closed: new Date().toISOString().split("T")[0],
                }),
            });

            setCloseQty("");
            setExitPrice("");
            setClosePnL("");
        } catch (err) {
            alert(err.message);
        }
    };

    return (
        <div style={{ marginTop: 12 }}>
            {trade.status === "OPEN" && (
                <>
                    <h4>Partial Close</h4>

                    <input
                        type="number"
                        placeholder="Qty to close"
                        value={closeQty}
                        step="0.01"
                        onChange={(e) => setCloseQty(e.target.value)}
                    />

                    <input
                        type="number"
                        placeholder="Exit price"
                        value={exitPrice}
                        step="0.0001"
                        onChange={(e) => setExitPrice(e.target.value)}
                    />

                    <input
                        type="number"
                        placeholder="PnL gained"
                        value={closePnL}
                        step="0.01"
                        onChange={(e) => setClosePnL(e.target.value)}
                    />

                    <button onClick={handlePartialClose}>
                        Close Partial
                    </button>
                </>
            )}

            {trade.partial_closes?.length > 0 && (
                <div style={{ marginTop: 10 }}>
                    <b>Partial Closes</b>
                    {trade.partial_closes.map((pc, i) => (
                        <div key={i}>
                            Qty: {pc.qty} @ {pc.exit_price} → PnL: {pc.pnl}
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
}

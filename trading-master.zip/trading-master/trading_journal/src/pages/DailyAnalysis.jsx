﻿import { useContext, useEffect, useState } from "react";
import { AuthContext } from "../context/AuthContext";
import { db, storage } from "../utils/firebase";
import {
    addDoc,
    collection,
    doc,
    getDoc,
    serverTimestamp,
    updateDoc,
} from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { useNavigate, useParams } from "react-router-dom";

export default function DailyAnalysis() {
    const { user } = useContext(AuthContext);
    const { id } = useParams();
    const navigate = useNavigate();

    if (!user) return <p>Loading user...</p>;

    const isEdit = Boolean(id);

    const [pair, setPair] = useState("");
    const [bias, setBias] = useState("");
    const [executionPlan, setExecutionPlan] = useState("");

    const [preImages, setPreImages] = useState({});
    const [postImages, setPostImages] = useState({});

    const [reflection, setReflection] = useState("");
    const [lessons, setLessons] = useState("");

    useEffect(() => {
        if (!isEdit) return;

        const loadAnalysis = async () => {
            const snap = await getDoc(doc(db, "daily_analysis", id));
            if (!snap.exists()) return;

            const data = snap.data();
            setPair(data.pair || "");
            setBias(data.pre?.bias || "");
            setExecutionPlan(data.pre?.executionPlan || "");
            setPreImages(data.pre?.images || {});
            setPostImages(data.post?.images || {});
            setReflection(data.post?.reflection || "");
            setLessons(data.post?.lessons || "");
        };

        loadAnalysis();
    }, [id, isEdit]);

    const uploadImage = async (file, section, tf) => {
        if (!file) return null;
        const path = `users/${user.uid}/daily_analysis/${Date.now()}_${section}_${tf}.png`;
        const refImg = ref(storage, path);
        await uploadBytes(refImg, file);
        return await getDownloadURL(refImg);
    };

    const handleSave = async () => {
        if (!pair) return alert("Pair required");

        if (!isEdit) {
            await addDoc(collection(db, "daily_analysis"), {
                userId: user.uid,
                date: new Date().toISOString().split("T")[0],
                pair,
                pre: {
                    bias,
                    executionPlan,
                    images: preImages,
                },
                createdAt: serverTimestamp(),
            });
        } else {
            await updateDoc(doc(db, "daily_analysis", id), {
                post: {
                    reflection,
                    lessons,
                    images: postImages,
                },
                updatedAt: serverTimestamp(),
            });
        }

        navigate("/dashboard");
    };

    return (
        <div style={{ padding: 20 }}>
            <h2>{isEdit ? "Post-Session Analysis" : "Pre-Session Analysis"}</h2>

            {!isEdit && (
                <>
                    <input
                        placeholder="Forex Pair (EURUSD)"
                        value={pair}
                        onChange={(e) => setPair(e.target.value)}
                    />

                    <textarea
                        placeholder="Market Bias"
                        value={bias}
                        onChange={(e) => setBias(e.target.value)}
                    />

                    <textarea
                        placeholder="Execution Plan"
                        value={executionPlan}
                        onChange={(e) => setExecutionPlan(e.target.value)}
                    />

                    <h4>Pre-Session Charts</h4>

                    {["H1", "M15", "M5"].map(tf => (
                        <input
                            key={tf}
                            type="file"
                            onChange={async (e) => {
                                const url = await uploadImage(e.target.files[0], "pre", tf);
                                setPreImages(p => ({ ...p, [tf]: url }));
                            }}
                        />
                    ))}
                </>
            )}

            {isEdit && (
                <>
                    <h4>Post-Session Reflection</h4>

                    <textarea
                        placeholder="How did price move vs expectation?"
                        value={reflection}
                        onChange={(e) => setReflection(e.target.value)}
                    />

                    <textarea
                        placeholder="Lessons"
                        value={lessons}
                        onChange={(e) => setLessons(e.target.value)}
                    />

                    <h4>Post-Session Charts</h4>

                    {["H1", "M15", "M5"].map(tf => (
                        <input
                            key={tf}
                            type="file"
                            onChange={async (e) => {
                                const url = await uploadImage(e.target.files[0], "post", tf);
                                setPostImages(p => ({ ...p, [tf]: url }));
                            }}
                        />
                    ))}
                </>
            )}

            <button onClick={handleSave}>
                {isEdit ? "Save Post Analysis" : "Save Pre Analysis"}
            </button>
        </div>
    );
}

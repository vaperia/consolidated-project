﻿import { useContext, useEffect, useMemo, useState } from "react";
import { AuthContext } from "../context/AuthContext";
import { db } from "../utils/firebase";
import { collection, getDocs, query, where } from "firebase/firestore";

function ymd(d) {
    return d.toISOString().slice(0, 10);
}

export default function Calendar() {
    const { user } = useContext(AuthContext);
    const [month, setMonth] = useState(() => new Date());
    const [dailyPnL, setDailyPnL] = useState({}); // { "YYYY-MM-DD": number }
    const [selectedDate, setSelectedDate] = useState(ymd(new Date()));
    const [dayTrades, setDayTrades] = useState([]);

    const monthStart = useMemo(() => new Date(month.getFullYear(), month.getMonth(), 1), [month]);
    const monthEnd = useMemo(() => new Date(month.getFullYear(), month.getMonth() + 1, 0), [month]);

    useEffect(() => {
        const loadMonth = async () => {
            // simple approach: fetch all trades for user, aggregate by date
            // (fine for personal journal; we can optimize later)
            const q = query(collection(db, "trades"), where("userId", "==", user.uid));
            const snap = await getDocs(q);
            const map = {};
            snap.forEach((doc) => {
                const t = doc.data();
                if (!t.date) return;
                map[t.date] = (map[t.date] || 0) + Number(t.pnl || 0);
            });
            setDailyPnL(map);
        };
        loadMonth();
    }, [user.uid]);

    useEffect(() => {
        const loadDay = async () => {
            const q = query(
                collection(db, "trades"),
                where("userId", "==", user.uid),
                where("date", "==", selectedDate)
            );
            const snap = await getDocs(q);
            setDayTrades(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
        };
        loadDay();
    }, [user.uid, selectedDate]);

    const daysInMonth = monthEnd.getDate();
    const firstWeekday = monthStart.getDay(); // 0-6

    return (
        <div className="container">
            <h2>Calendar</h2>
            <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
                <button onClick={() => setMonth(new Date(month.getFullYear(), month.getMonth() - 1, 1))}>◀</button>
                <b>{month.toLocaleString(undefined, { month: "long", year: "numeric" })}</b>
                <button onClick={() => setMonth(new Date(month.getFullYear(), month.getMonth() + 1, 1))}>▶</button>
                <a style={{ marginLeft: "auto" }} href="/dashboard">Back</a>
            </div>

            <div style={{ marginTop: 12, display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 8 }}>
                {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((d) => (
                    <div key={d} style={{ opacity: 0.8, fontSize: 12 }}>{d}</div>
                ))}

                {Array.from({ length: firstWeekday }).map((_, i) => (
                    <div key={`pad-${i}`} />
                ))}

                {Array.from({ length: daysInMonth }).map((_, i) => {
                    const day = i + 1;
                    const dateStr = ymd(new Date(month.getFullYear(), month.getMonth(), day));
                    const pnl = dailyPnL[dateStr] || 0;

                    return (
                        <button
                            key={dateStr}
                            onClick={() => setSelectedDate(dateStr)}
                            style={{
                                textAlign: "left",
                                padding: 10,
                                borderRadius: 10,
                                border: dateStr === selectedDate ? "2px solid #666" : "1px solid #333",
                                background: "transparent",
                                cursor: "pointer",
                            }}
                        >
                            <div style={{ fontWeight: 700 }}>{day}</div>
                            <div style={{ fontSize: 12, opacity: 0.9 }}>
                                PnL: {pnl.toFixed(2)}
                            </div>
                        </button>
                    );
                })}
            </div>

            <h3 style={{ marginTop: 18 }}>Review: {selectedDate}</h3>
            <div style={{ display: "grid", gap: 10 }}>
                {dayTrades.length === 0 ? <div>No trades for this date.</div> : null}
                {dayTrades.map((t) => (
                    <div key={t.id} style={{ padding: 12, border: "1px solid #333", borderRadius: 10 }}>
                        <b>{t.ticker} ({t.direction})</b>
                        <div>Entry: {t.entry_price} → Exit: {t.exit_price} | Qty: {t.quantity}</div>
                        <div>PnL: {Number(t.pnl).toFixed(2)}</div>
                        {t.notes ? <div>Notes: {t.notes}</div> : null}
                        {t.screenshot_url ? (
                            <img src={t.screenshot_url} alt="screenshot" style={{ marginTop: 10, maxWidth: 320, borderRadius: 10 }} />
                        ) : null}
                    </div>
                ))}
            </div>
        </div>
    );
}

﻿import { useContext, useState } from "react";
import { AuthContext } from "../context/AuthContext";
import { db, storage } from "../utils/firebase";
import { addDoc, collection, serverTimestamp } from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";

export default function AddTrade() {
    const { user } = useContext(AuthContext);

    const [form, setForm] = useState({
        date_opened: "",
        ticker: "",
        direction: "",
        entry_price: "",
        quantity: "",
        strategy: "",
    });

    const [charts, setCharts] = useState({
        H1: null,
        M15: null,
        M5: null,
    });

    const [loading, setLoading] = useState(false);

    const handleChange = (e) =>
        setForm({ ...form, [e.target.name]: e.target.value });

    const uploadChart = async (file, tf) => {
        if (!file) return null;
        const path = `users/${user.uid}/trades/${Date.now()}_${tf}.png`;
        const imgRef = ref(storage, path);
        await uploadBytes(imgRef, file);
        return await getDownloadURL(imgRef);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);

        try {
            const uploadedCharts = {
                H1: await uploadChart(charts.H1, "H1"),
                M15: await uploadChart(charts.M15, "M15"),
                M5: await uploadChart(charts.M5, "M5"),
            };

            await addDoc(collection(db, "trades"), {
                userId: user.uid,
                status: "OPEN",

                ticker: form.ticker.toUpperCase(),
                direction: form.direction,

                entry_price: Number(form.entry_price),
                quantity: Number(form.quantity),
                remaining_qty: Number(form.quantity),

                strategy: form.strategy,

                charts: uploadedCharts,

                partial_closes: [],
                pnl: 0,

                date_opened: form.date_opened,
                date_closed: null,

                createdAt: serverTimestamp(),
            });

            alert("Trade opened");
            window.location.href = "/dashboard";
        } catch (err) {
            alert(err.message);
        } finally {
            setLoading(false);
        }
    };

    return (
        <div className="container">
            <h2>Open Trade</h2>

            <form onSubmit={handleSubmit} style={{ display: "grid", gap: 10 }}>
                <input type="date" name="date_opened" onChange={handleChange} required />
                <input name="ticker" placeholder="Pair (EURUSD)" onChange={handleChange} required />

                <select name="direction" onChange={handleChange} required>
                    <option value="">Direction</option>
                    <option value="LONG">LONG</option>
                    <option value="SHORT">SHORT</option>
                </select>

                <input type="number" step="0.0001" name="entry_price" placeholder="Entry Price" onChange={handleChange} required />
                <input type="number" step="0.01" name="quantity" placeholder="Position Size" onChange={handleChange} required />

                <textarea
                    name="strategy"
                    placeholder="Strategy / confirmation (OB → Breaker → Retest → Engulf)"
                    onChange={handleChange}
                    required
                />

                <h4>Entry Charts</h4>

                <label>1H</label>
                <input type="file" accept="image/*" onChange={(e) => setCharts(c => ({ ...c, H1: e.target.files[0] }))} />

                <label>15M</label>
                <input type="file" accept="image/*" onChange={(e) => setCharts(c => ({ ...c, M15: e.target.files[0] }))} />

                <label>5M</label>
                <input type="file" accept="image/*" onChange={(e) => setCharts(c => ({ ...c, M5: e.target.files[0] }))} />

                <button disabled={loading}>
                    {loading ? "Saving..." : "Open Trade"}
                </button>
            </form>
        </div>
    );
}

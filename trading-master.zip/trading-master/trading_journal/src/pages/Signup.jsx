import { useContext, useState } from "react";
import { AuthContext } from "../context/AuthContext";

export default function Signup() {
    const { signup } = useContext(AuthContext);
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await signup(email, password);
            window.location.href = "/dashboard";
        } catch (err) {
            alert(err.message);
        }
    };

    return (
        <div className="container">
            <h2>Sign Up</h2>
            <form onSubmit={handleSubmit} style={{ display: "grid", gap: 10 }}>
                <input placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} />
                <input placeholder="Password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
                <button>Sign Up</button>
            </form>
            <a href="/">Back to Login</a>
        </div>
    );
}

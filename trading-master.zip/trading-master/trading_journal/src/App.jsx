import { BrowserRouter, Routes, Route } from "react-router-dom";
import AuthProvider from "./context/AuthContext";
import ProtectedRoute from "./components/ProtectedRoute";

import Login from "./pages/Login";
import Signup from "./pages/Signup";
import Dashboard from "./pages/Dashboard";
import AddTrade from "./pages/AddTrade";
import Calendar from "./pages/Calendar";
import DailyAnalysis from "./pages/DailyAnalysis";
import TradeJournal from "./pages/TradeJournal";


export default function App() {
    return (
        <AuthProvider>
            <BrowserRouter>
                <Routes>
                    <Route path="/" element={<Login />} />
                    <Route path="/signup" element={<Signup />} />

                    <Route
                        path="/dashboard"
                        element={
                            <ProtectedRoute>
                                <Dashboard />
                            </ProtectedRoute>
                        }
                    />

                    <Route
                        path="/add-trade"
                        element={
                            <ProtectedRoute>
                                <AddTrade />
                            </ProtectedRoute>
                        }
                    />

                    <Route
                        path="/calendar"
                        element={
                            <ProtectedRoute>
                                <Calendar />
                            </ProtectedRoute>
                        }
                    />

                    <Route
                        path="/analysis"
                        element={
                            <ProtectedRoute>
                                <DailyAnalysis />
                            </ProtectedRoute>
                        }
                    />

                    <Route
                        path="/analysis/:id"
                        element={
                            <ProtectedRoute>
                                <DailyAnalysis />
                            </ProtectedRoute>
                        }
                    />

                    <Route path="/trade-journal" element={<TradeJournal />} />

                </Routes>
            </BrowserRouter>
        </AuthProvider>
    );
}
